// A $( document ).ready() block.
$( document ).ready(function() {
    //console.log( "ready!" );
  //alert('this is an example alert')
  
  $('.carousel').carousel({
  interval: 2000
})
  
});
